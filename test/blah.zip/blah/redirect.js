
const url = require('url');

module.exports = function redirect(reqObj, rule, log) {

  // proper descriptions
  let desc = {
    "status-301": "Moved Permanently",
    "status-302": "Found",
    "status-307": "Temporary Redirect",
  };

  let qs = "", incomingQS = "", responseQS = "?", locationQS = "";

  let loc = rule.location;

  // if we need to copy the req.uri query string and merge it with rule.location query string
  if (rule.qsa) {
    loc = determineQueryString(reqObj.uri, reqObj.querystring, rule.location);
  }

  // Create a custom response
  const newResponse = {
    status: rule.status,
    statusDescription: desc[`stratus-${rule.status}`],
    headers: {
      location: [{
        key: 'location',
        value: loc,
      }],
    },
  };

  // Check if cache control is defined in the rule
  if (rule.cacheControl) {
    newResponse.headers['cache-control'] = [{ key: 'Cache-Control', value: `max-age=${rule.cacheControl}` }];
  }

  return newResponse;
};

function determineQueryString(matchingUri, incomingQS, locationUri){
  let responseQS = '';

  // if there is query string on the current location, append
  if (incomingQS) {
    responseQS += incomingQS;
  }

  // the redirect location, in case it has some url
  const responseParsed = url.parse(locationUri);
  const locationQS = responseParsed.query;

  // add the location query string
  if (locationQS) {
    responseQS += (responseQS.endsWith('&')) ? locationQS : `&${locationQS}`;
  }

  if (responseQS) {
    responseQS = (responseQS.startsWith('?')) ? responseQS : `?${responseQS}`;
  }

  let host = '';

  // if there is no host, leave it empty
  if (responseParsed.hostname) {
    host = `${responseParsed.protocol}//${responseParsed.hostname}`;
  }

  // loc = host + pathname + any query strings
  return `${host}${(responseParsed.pathname ? responseParsed.pathname : '')}${responseQS}`;
}
