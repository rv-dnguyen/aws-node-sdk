import mocha from 'mocha';
import request from 'request';
import http from 'http';
import { expect, assert } from 'chai';
import lambda from '../';

function buildEvent(path, qs = ''){
  const req = {
    "Records": [
      {
        "cf": {
          "request": {
            "headers": {
              "host": [
                {
                  "value": "d123.cf.net",
                  "key": "Host"
                }
              ],
              "user-agent": [
                {
                  "value": "test-agent",
                  "key": "User-Agent"
                }
              ],
              "authorization": [
                {
                  "key": "Authorization",
                  "value": "Basic cnYtZmVkOkRGR0hVSSomXiUkRURGR0hKVVRSRVNYQ1ZCSFlUUkVTWlhDVkJO"
                }
              ],
            },
            "clientIp": "2001:cdba::3257:9652",
            "uri": "",
            "querystring": "",
            "method": "GET",
            "origin": {
              "custom": {
                "customHeaders": {},
                "domainName": "cloudservices.redventures.com",
                "keepaliveTimeout": 5,
                "path": "",
                "port": 443,
                "protocol": "https",
                "readTimeout": 30,
                "sslProtocols": [
                  "TLSv1",
                  "TLSv1.1",
                  "TLSv1.2"
                ]
              }
            },
          },
          "response": {
            "status": 200,
            "body": "hello world",
            "headers": {}
          },
          "config": {
            "distributionId": "EXAMPLE"
          }
        }
      }
    ]
  };
  req.Records[0].cf.request.uri = path;
  req.Records[0].cf.request.querystring = qs;
  return req;
}

/**
 * @desc Will format an object of headers (key:value) and format them in a Lambda@Edge format
 * @param {Object} headersArr
 * @returns {Object} expectedHeaders (key:Array[key, value]);
 */
function formatExpectedHeaders(headersArr) {
  const expectedHeaders = {};

  // No headers? We return an empty object
  if (!headersArr) {
    return expectedHeaders;
  }

  // Add each header object defined to the appropriate header array
  headersArr.forEach((headerObj, index) => {
    const headerObjKeys = Object.keys(headerObj);

    // For each of the keys found in the object, create a new header
    headerObjKeys.forEach((key, index) => {
      const header = { key: key, value: headerObj[key] };

      // Verify the header key isn't already in use, if it is, just add to the array
      if (expectedHeaders[key]) {
        expectedHeaders[key].push(header);
      } else {
        expectedHeaders[key] = [header];
      }
    });
  });

  return expectedHeaders;
}

describe('Test response local functions', function() {
  it('should return configured custom headers', function (done) {
    // Grab the headers from this config file
    const config = require('../stratus-config');

    lambda.setConfig(config);
    const expectedHeaders = formatExpectedHeaders([config.customResponseHeaders]);

    const event = buildEvent('/');
    console.log(`expectedHeaders: ${JSON.stringify(expectedHeaders, null, 2)}`);
    console.log(`config.customResponseHeaders: ${JSON.stringify(config.customResponseHeaders, null, 2)}`);
    lambda.handler(event, {}, function (err, resp) {
      expect(err).to.equal(null); // come on kyle...
      expect(resp.headers).to.eql(expectedHeaders);
      done();
    });
  });

  it('should not add headers since we are passing in a config with no headers', function (done) {
    const expectedHeaders = {};

    const event = buildEvent("/");
    // Set the config to one that has no headers to set
    lambda.setConfig({ customResponseHeaders: {} });
    lambda.handler(event, {}, function(err, resp) {
      expect(err).to.equal(null); // make sure there is no error
      expect(resp.headers).to.eql(expectedHeaders);
      done();
    });
  });

  it('should have the headers that are specified not from the stratus-config.json', function (done) {
    const config = require('../stratus-config');
    config.customResponseHeaders = {
      'x-stratus-header': 'hello from stratus',
      'x-stratus-env': 'production',
      'x-stratus-siteName': 'www.test.com',
      'x-stratus-generator': 'hexo',
      'x-stratus-debug': 'this is another header',
    };
    config.customResponseHeadersByType = null;
    lambda.setConfig(config);
    const expectedHeaders = formatExpectedHeaders([config.customResponseHeaders]);
    const event = buildEvent('/');
    lambda.setConfig(config);
    lambda.handler(event, {}, function (err ,resp) {
      expect(err).to.equal(null);
      expect(resp.headers).to.eql(expectedHeaders);
      expect(Object.keys(resp.headers)).to.be.of.lengthOf(Object.keys(expectedHeaders).length);
      done();
    });
  });

  it('should have the custom response cache headers by type that are specified', function (done) {
    // Set the config to one that has no headers to set
    const config = require('../stratus-config');
    config.customResponseHeaders = null;
    config.customResponseHeadersByType = {
      'text/html': [
        {
          'cache-control': 'max-age=99999',
        },
        {
          'x-custom-1': 'nah-bruh',
        },
        {
          'x-custom-2': 'some-other-value',
        },
      ],
      'text/css': [
        {
          'cache-control': 'max-age=99999',
        },
      ],
      'text/javascript': [
        {
          'cache-control': 'max-age=99999',
        },
      ],
      'image/jpg': [
        {
          'cache-control': 'max-age=99999',
        },
      ],
      'image/png': [
        {
          'cache-control': 'max-age=99999',
        },
        {
          'x-custom-1': 'nah-bruh',
        },
        {
          'x-custom-2': 'some-other-value',
        },
        {
          'x-custom-3': 'nah-bruh-again',
        },
        {
          'x-custom-4': 'this-is-alot-of-headers',
        },
      ],
    };

    const customRespContentTypes = Object.keys(config.customResponseHeadersByType);

    // Test each content type defined
    customRespContentTypes.forEach((contentType, index) => {
      const cacheHeaderArr = config.customResponseHeadersByType[contentType];
      const expectedHeaders = formatExpectedHeaders(cacheHeaderArr);

      // Set the content type header
      const contentHeader = [{ key: 'content-type', value: contentType }];
      expectedHeaders['content-type'] = contentHeader;
      const event = buildEvent('/');
      event.Records[0].cf.response.headers['content-type'] = contentHeader;
      lambda.setConfig(config);
      lambda.handler(event, {}, (err, resp) => {
        expect(err).to.equal(null);
        expect(resp.headers).to.eql(expectedHeaders);
      });
    });

    done();
  });

  it('should have the custom headers that are specified not from the stratus-config.json', function(done) {
    const config = require('../stratus-config');
    config.customResponseHeaders = {
      'x-stratus-header': 'hello from stratus',
      'x-stratus-env': 'production',
      'x-stratus-siteName': 'www.test.com',
      'x-stratus-generator': 'hexo',
      'x-stratus-debug': 'this is another header',
      'Content-Security-Policy': "default-src: 'self'; img-src *; script-src *",
    };
    config.customResponseHeadersByType = null;
    lambda.setConfig(config);
    const expectedHeaders = formatExpectedHeaders([config.customResponseHeaders]);
    const event = buildEvent('/');
    lambda.setConfig(config);
    lambda.handler(event, {}, function (err ,resp) {
      expect(err).to.equal(null);
      expect(resp.headers).to.eql(expectedHeaders);
      expect(Object.keys(resp.headers)).to.be.of.lengthOf(Object.keys(expectedHeaders).length);
      done();
    });
  });

  it('should return a 416 status code', function(done) {
    const event = buildEvent("/");
    // Set the status code to something > 307
    event.Records[0].cf.response.status = 403;

    lambda.handler(event, {}, function(err, resp) {
      expect(err).to.equal(null);
      expect(resp.status).to.equal('416');
      done();
    });
  });

  it('should return 200 status code, should not modify the 200 resp', function(done) {
    const event = buildEvent("/");
    const config = require('../stratus-config');
    config.customResponseHeaders = null;
    lambda.setConfig(config);
    lambda.handler(event, {}, function (err, resp) {
      expect(err).to.equal(null);
      expect(resp.status).to.equal(200);
      done();
    });
  });

  it('should have multiple of same custom response cache header by type that are specified', function (done) {
    const config = require('../stratus-config');
    config.customResponseHeaders = null;
    config.customResponseHeadersByType = {
      'text/html': [
        {
          'cache-control': 'max-age=99999',
        },
        {
          'set-cookie': 'some-value',
        },
        {
          'set-cookie': 'some-other-value',
        },
      ],
          'text/css': [
        {
          'x-custom-1': 'nah-bruh',
        },
        {
          'set-cookie': 'some-value',
        },
        {
          'x-custom-1': 'nah-bruh-again',
        },
        {
          'set-cookie': 'some-value-again',
        },
      ],
          'text/javascript': [
        {
          'cache-control': 'max-age=99999',
        },
        {
          'x-custom-1': 'nah-bruh',
        },
        {
          'x-custom-1': 'nah-bruh-again',
        },
      ],
    };
    //lambda.setConfig(config);
    const customRespContentTypes = Object.keys(config.customResponseHeadersByType);
    //const event = buildEvent('/');

    // Test each content type defined
    customRespContentTypes.forEach((contentType, index) => {
      const expectedHeaders = {};
      const customCacheHeaderArr = config.customResponseHeadersByType[contentType];

      // Add each header object defined to the appropriate header array
      customCacheHeaderArr.forEach((headerObj, index) => {
        const headerObjKeys = Object.keys(headerObj);
        const headerObjKey = headerObjKeys[0].toLowerCase();
        const header = { key: headerObjKey, value: headerObj[headerObjKey] };

        if (expectedHeaders[headerObjKey]) {
          expectedHeaders[headerObjKey].push(header);
        } else {
          expectedHeaders[headerObjKey] = [header];
        }
      });

      // Add the content type header
      const contentHeader = [{ key: 'content-type', value: contentType }];
      expectedHeaders['content-type'] = contentHeader;
      const event = buildEvent('/');
      event.Records[0].cf.response.headers['content-type'] = contentHeader;
      lambda.setConfig(config);
      lambda.handler(event, {}, (err, resp) => {
        expect(err).to.equal(null);
        expect(resp.headers).to.eql(expectedHeaders);
      });
    });

    done();
  });

  it('should use custom error handling specified for body', function(done) {
    const config = require('../stratus-config');
    const event = buildEvent('/testing');
    const testRule = config.rules.find((rule) => {
          return rule.status === 314;
      });
    const testErrorObj = config.customErrorHandling[testRule.status.toString()];

    event.Records[0].cf.response = null;
    config.rules.push(testRule); // Add test rule to config
    config.customErrorHandling[`${testRule.status.toString()}`] = testErrorObj; // Add custom error to config
    lambda.setConfig(config);
    lambda.handler(event, {}, function (err, resp) {
      expect(err).to.equal(null);
      expect(resp.body).to.eql(config.customErrorHandling[`${testRule.status.toString()}`].body);
      done();
    });
  });

  it('should use custom error handling specified for path', function(done) {
    const config = require('../stratus-config');
    const event = buildEvent('/oh-no-aint-here');
    const testRule = config.rules.find((rule) => {
      return rule.status === 410;
    });
    const testErrorObj = config.customErrorHandling[testRule.status.toString()];

    event.Records[0].cf.response = null;
    lambda.setConfig(config);
    lambda.handler(event, {}, function (err, resp) {
      expect(err).to.equal(null);
      expect(resp.uri).to.eql(testErrorObj.path);
      done();
    });
  });
});
