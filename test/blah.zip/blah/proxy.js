/**
 * @desc takes in a Lambda@Edge request and proxies it to a modified destination
 * @param {*} req 
 * @param {*} origin
 * @param {*} rule  
 */
module.exports = function proxy(req, origin, rule) {
  // TODO: remove this?
  // set auth if its cloud services, otherwise, replace the origin with the rule's origin
  if(origin.host == "cloudservices.redventures.com"){
    origin.customHeaders["authorization"] = [{ key: 'authorization', value: "Basic cnYtZmVkOkhZJVJmZGU0cnRnZmRlJCVUWSY2NXJmZ2h5NjU0ZWQ="}];
    req.headers["authorization"] = [{ key: 'authorization', value: "Basic cnYtZmVkOkhZJVJmZGU0cnRnZmRlJCVUWSY2NXJmZ2h5NjU0ZWQ="}];
  } else{
    req.origin = {
      custom: origin
    };    
  }

  // If rule uses new proxy format w/ capturing group redirects
  if (rule.location) {
    req.uri = rule.location;  // set url to new location
  } else if (rule && rule.find && rule.replace) { // old format of find and replace
    req.uri = req.uri.replace(rule.find, rule.replace);
  }
  
  req.origin.custom.domainName = origin.host;
  req.headers['host'] = [{ key: 'host', value: origin.host }];
  return req;
}