#!/bin/bash
CLOUDFRONT_COMMENT=$1
STACK_NAME=$2
NEW_LAMBDA=`aws cloudformation describe-stacks --stack-name $STACK_NAME --query Stacks[0].Outputs[0].OutputValue --output text --region us-east-1`
aws lambda invoke --invocation-type RequestResponse --function-name lambda-edge-cloudfront-updater --region us-east-1 --log-type Tail --payload '{"cloudfront_distribution_comment": "'${CLOUDFRONT_COMMENT}'","default_behavior_event_type": "origin-request","default_behavior_lambda_arn": "'$NEW_LAMBDA'"}' --region us-east-1 output.txt