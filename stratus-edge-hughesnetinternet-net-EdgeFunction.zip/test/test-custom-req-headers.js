import mocha from 'mocha';
import request from 'request';
import http from 'http';
import chai, { expect, assert } from 'chai';

import getCustomheaders from '../lib/getCustomHeaders';

function buildRequest(path, qs){
  const req = {
    "Records": [
      {
        "cf": {
          "request": {
            "headers": {
              "host": [
                {
                  "value": "d123.cf.net",
                  "key": "Host"
                }
              ],
              "user-agent": [
                {
                  "value": "test-agent",
                  "key": "User-Agent",
                },
              ],
              "authorization": [
                {
                  "key": "Authorization",
                  "value": "Basic cnYtZmVkOkRGR0hVSSomXiUkRURGR0hKVVRSRVNYQ1ZCSFlUUkVTWlhDVkJO",
                }
              ],
            },
            "clientIp": "2001:cdba::3257:9652",
            "uri": "",
            "querystring": "",
            "method": "GET",
            "origin": {
              "custom": {
                  "customHeaders": {
                      "x-stratus-config-path": [
                          {
                              "key": "x-stratus-config-path",
                              "value": "home-security.co/stratus-config.json"
                          }
                      ],
                      "x-stratus-env": [
                          {
                              "key": "x-stratus-env",
                              "value": "development"
                          }
                      ]
                  },
                  "domainName": "cloudservices.redventures.com",
                  "keepaliveTimeout": 5,
                  "path": "",
                  "port": 443,
                  "protocol": "https",
                  "readTimeout": 30,
                  "sslProtocols": [
                      "TLSv1",
                      "TLSv1.1",
                      "TLSv1.2"
                  ]
              }
            },
          },
          "config": {
            "distributionId": "EXAMPLE"
          },
        },
      },
    ],
  };
  req.Records[0].cf.request.uri = path;
  req.Records[0].cf.request.querystring = qs;
  return req;
}

describe('Test local getCustomHeaders function', function () {
  it('should find both headers on the origin', function (done) {
    const req = buildRequest('/').Records[0].cf.request;
    const expectedHeaders = req.origin.custom.customHeaders;

    console.log('expected headers', expectedHeaders);
    const headers = getCustomheaders(req);

    console.log('actual headers', headers);
    expect(headers).to.eql(expectedHeaders);
    done();
  });
});
