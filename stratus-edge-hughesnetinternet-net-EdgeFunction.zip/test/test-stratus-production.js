import mocha from 'mocha';
import request from 'request';
import chai, { expect, assert } from 'chai';

var domain = "https://d2m6k3gakydft8.cloudfront.net";
//var domain = "http://home-security.co";

describe(`Test production cloudfront ${domain}`, function() {

    it(`redirect index.html to slash`, function(done) {
		request.get(domain + "/index.html", { followRedirect: false }, function(err, resp, body) {
		    if (err) done(err);
		    expect(resp.statusCode).to.be.within(301,302);
		    expect(resp.headers["location"]).to.equal("/");
		    done();
		});	
	});

    it(`proxy slash to index.html`, function(done) {
		request.get(domain + "/", { followRedirect: false }, function(err, resp, body) {
		    if (err) done(err);
		    expect(resp.statusCode).to.be.equal(200);
		    expect(resp.body).to.contain("<html");
		    done();
		});	
	});

    it(`redirect rule example-whatever to slash`, function(done) {
		request.get(domain + "/example-whatever", { followRedirect: false }, function(err, resp, body) {
		    if (err) done(err);
		    expect(resp.statusCode).to.be.equal(302);
		    expect(resp.headers["location"]).to.equal("/");
		    done();
		});	
	});

    it(`external redirect rule other-whatever to google`, function(done) {
		request.get(domain + "/other-whatever1234", { followRedirect: false }, function(err, resp, body) {
		    if (err) done(err);
		    expect(resp.statusCode).to.be.equal(302);
		    expect(resp.headers["location"]).to.equal("https://www.google.com/");
		    done();
		});	
	});

    it(`test 404 gives the correct status page`, function(done) {
		request.get(domain + "/omg-this-doesnt-exist", { followRedirect: false }, function(err, resp, body) {
		    if (err) done(err);
		    expect(resp.statusCode).to.be.equal(404);
		    expect(resp.body).to.contain("404");
		    done();
		});
	});

	it('Proxy to hailo', function(done) {
		request.get(domain + "/stratus/hailo.php?url=http%3A%2F%2Fhome-security.co%2Fplans-pricing%2F&ref=&cd=" + domain.replace(/https?:\/\//,''), { followRedirect: false }, function(err, resp, body) {
			if (err) done(err);
			
			expect(resp.statusCode).to.be.equal(200);
			// look for the hud cookie in the set-cookie header
			const hud = resp.headers['set-cookie'].find(function(cookie){
				return cookie.indexOf('hud') >= 0;
			});

			expect(hud).to.contain('hud=');

			// look for the phpsssid cookie in the set-cookie header
			const phpsssid = resp.headers['set-cookie'].find(function(cookie){
				return cookie.indexOf('PHPSESSID') >= 0;
			});

			expect(phpsssid).to.contain('PHPSESSID=');

			// make sure we miss cloudfront
			expect(resp.headers['x-cache']).to.equal('Miss from cloudfront');
			expect(resp.body).to.contain('hQ.on');
		    done();
		});
	});
	
	it('proxy LEAD cloudservices.redventures.com endpoint', function(done) {
		// leads are slow
		this.timeout(5000);

		let leadObj = {
		  "ConsentDisclosureID": "573",
		  "DisclosureHash": "a2ccfd7eb88a5001002eaba6f3856249",
		  "FirstName": "Celio",
		  "LastName": "McPeterson",
		  "MarketingProgramID": "1282787",
		  "Phone1": "735-511-" + Math.round(Math.random()*10000).toString(),
		  "SiteName": "home-security.co",
		  "ZipCode": "28101",
		  "Live": "false"
		};

		let options = {
		  url: domain + "/api/createLead.php",
		  method: "POST",
		  headers: {
		    'Content-Type': 'application/json',
		    "User-Agent": "testing, 123"
		  },
		  body: leadObj,
		  json: true
		};

		request(options, function(err,resp,body){
		    if (err) done(err);

		    expect(resp.statusCode).to.be.equal(200);
			expect(resp.headers['x-cache']).to.equal('Miss from cloudfront');
		    expect(resp.body).to.be.an('object');
		    expect(resp.body.leadArray).to.be.an('object');
		    expect(Object.keys(resp.body.leadArray).length).to.be.greaterThan(1);

		    done();
		});
	});
});
