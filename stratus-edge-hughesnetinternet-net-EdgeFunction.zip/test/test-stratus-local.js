import mocha from 'mocha';
import request from 'request';
import http from 'http';
import chai, { expect, assert } from 'chai';

const lambda = require('../index');

function buildRequest(path, qs = '') {
  const req = {
    "Records": [
      {
        "cf": {
          "request": {
            "headers": {
              "host": [
                {
                  "value": "d123.cf.net",
                  "key": "Host"
                }
              ],
              "user-agent": [
                {
                  "value": "test-agent",
                  "key": "User-Agent"
                }
               ],
              "authorization": [
                  {
                      "key": "Authorization",
                      "value": "Basic cnYtZmVkOkRGR0hVSSomXiUkRURGR0hKVVRSRVNYQ1ZCSFlUUkVTWlhDVkJO"
                  }
              ],
            },
            "clientIp": "2001:cdba::3257:9652",
            "uri": "",
            "querystring": "",
            "method": "GET",
            "origin": {
              "custom": {
                  "customHeaders": {},
                  "domainName": "cloudservices.redventures.com",
                  "keepaliveTimeout": 5,
                  "path": "",
                  "port": 443,
                  "protocol": "https",
                  "readTimeout": 30,
                  "sslProtocols": [
                      "TLSv1",
                      "TLSv1.1",
                      "TLSv1.2"
                  ]
              }
            },
          },
          "config": {
            "distributionId": "EXAMPLE"
          }
        }
      }
    ]
  };
  req.Records[0].cf.request.uri = path;
  req.Records[0].cf.request.querystring = qs;
  return req;
}

describe('Test local functions', function() {
  afterEach(function(done) { // aka reset-inator
    // Reset the config for the next test to run
    lambda.setConfig(null);
    done();
  });

  it(`proxy slash to index.html`, function(done) {
    const stratusConfig = { 
      siteName: 'proxy.com',
      rules: [],
      origins: [],
    };

    const event = buildRequest('/'); // Build the request with qs

    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function(err, resp){
      // Now check the resp
      expect(err).to.equal(null); // come on kyle...
      expect(resp.uri).to.equal("/index.html");

      
			done();
    });
	});

  it(`redirect index.html slash`, function(done) {
    const stratusConfig = { 
      siteName: 'proxy.com',
      rules: [],
      origins: [],
    };

    const event = buildRequest("/index.html");

    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function(err, resp){
      expect(err).to.equal(null); // come on kyle...
      expect(resp.status).to.equal(301);
      expect(resp.headers.location[0].value).to.equal("/");
      done();
    });
	});

  it(`redirect rule example-whatever to slash`, function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      origins: [],
      rules: [
        {
          "type": "redirect",
          "matchPath": "^/example-.*",
          "location": "/",
          "status": 302,
          "caseSensitive": false,
          "qsa": true,
          "cacheControl": "3600",
        }
      ]
    }
    
    const event = buildRequest("/example-stuff");
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function(err, resp) {
			expect(err).to.equal(null); // come on kyle...
			expect(resp.status).to.equal(302);
			expect(resp.headers.location[0].value).to.equal("/");
			done();
		});
	});

  it(`external redirect rule rule other-stuff to google.com`, function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      origins: [],
      rules: [
        {
          "type": "redirect",
          "matchPath": "^/other-.*",
          "location": "https://www.google.com/",
          "status": 302,
          "caseSensitive": false,
          "qsa": true,
          "cacheControl": "600",
        }
      ]
    }
    const event = buildRequest("/other-page");
    lambda.setConfig(stratusConfig);
		lambda.handler(event, {}, function(err, resp) {
			expect(err).to.equal(null); // come on kyle...
			expect(resp.status).to.equal(302);
			expect(resp.headers.location[0].value).to.equal("https://www.google.com/");
			done();
		});
	});

  it('should redirect using capturing groups', function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      origins: [],
      rules: [
        {
          "type": "redirect",
          "matchPath": "^/geo\/([^/]+)\/([^/]+)\/",
          "location": "/notgeo/$2-$1/",
          "status": 301,
          "caseSensitive": false,
          "qsa": true,
          "cacheControl": "600",
        }
      ]
    }

    const event = buildRequest("/geo/NC/Charlotte/");
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function(err, resp) {
      expect(err).to.equal(null);
      expect(resp.status).to.equal(301);
      expect(resp.headers).to.include.keys(['location']);
      expect(resp.headers.location[0].value).to.equal('/notgeo/Charlotte-NC/');
      done();
    });
  })

  it('proxy to LEADS w/ capturing on cloudservices.redventures.com endpoint', function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      origins: [
        {
          "name": "rvservices",
          "host": "cloudservices.redventures.com",
          "port": 443,
          "protocol": "https",
          "path": "",
          "sslProtocols": ["TLSv1", "TLSv1.1"],
          "readTimeout": 5,
          "keepaliveTimeout": 5,
          "customHeaders": {}
        }
      ],
      rules: [
        {
          "type": "proxy",
          "origin": "rvservices",
          "matchPath": "^/api/(.*)",
          "location": "/stratus/$1"
        }
      ]
    }

    let event = buildRequest("/api/createLead.php");
    event.Records[0].cf.request.method = "POST";
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function (err, res) {
        expect(err).to.equal(null);
        expect(res.uri).to.equal('/stratus/createLead.php');
        expect(res.headers.host[0]["value"]).to.equal("cloudservices.redventures.com");
        done();
    });
  });

  it('proxy to LEADS w/o capturing on cloudservices.redventures.com endpoint', function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      origins: [
        {
          "name": "rvservices",
          "host": "cloudservices.redventures.com",
          "port": 443,
          "protocol": "https",
          "path": "",
          "sslProtocols": ["TLSv1", "TLSv1.1"],
          "readTimeout": 5,
          "keepaliveTimeout": 5,
          "customHeaders": {}
        }
      ],
      rules: [
        {
          "type": "proxy",
          "origin": "rvservices",
          "matchPath": "^/api/(.*)",
          "find": "/api",
          "replace": "/stratus"
        }
      ]
    }

    let event = buildRequest("/api/createLead.php");
    event.Records[0].cf.request.method = "POST";
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function (err, res) {
        expect(err).to.equal(null);
        expect(res.uri).to.equal('/stratus/createLead.php');
        expect(res.headers.host[0]["value"]).to.equal("cloudservices.redventures.com");
        done();
    });
  });


  it('should use proxy based on x-stratus-env defined in config rule', function (done) {
    const stratusConfig = {
      siteName: "site.com",
      origins: [
        {
          "name": "rick-and-morty-api",
          "host": "rickandmortyapi.com",
          "port": 443,
          "protocol": "https",
          "path": "",
          "sslProtocols": ["TLSv1", "TLSv1.1"],
          "readTimeout": 5,
          "keepaliveTimeout": 5,
          "customHeaders": {
            "x-stratus-hello": [
              {
                "key": "x-stratus-hello",
                "value": "world"
              }
            ]
          }
        }
      ],
      rules: [
        {
          "type": "proxy",
          "origin": "rick-and-morty-api",
          "matchPath": "^/some-staging-api/(.*)",
          "location": "/api/$1",
          "env": "staging"
        }
      ]
    }
    const stratusEnv = 'staging';
    const origUri = '/some-staging-api/2baf70d1-42bb-4437-b551-e5fed5a87abe';
    const ruleObj = stratusConfig.rules.find((rule) => {
      return rule.env === stratusEnv;
    });
    const originObj = stratusConfig.origins.find((origin) => {
      return origin.name === ruleObj.origin;
    });
    const event = buildRequest(origUri);

    // Add the stratus env header to the request
    event.Records[0].cf.request.origin.custom.customHeaders['x-stratus-env'] = [{ key: 'x-stratus-env', value: ruleObj.env }];

    // Updated the uri expected
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, (err, res) => {
      expect(err).to.equal(null);
      const { headers } = res;
      Object.keys(headers).forEach((key, index) => {
        expect(Array.isArray(headers[key])).to.equal(true);
      });
      expect(headers.host[0].value).to.equal(originObj.host);
      if (ruleObj.find && ruleObj.replace) {
        const expectedUri = origUri.replace(ruleObj.find, ruleObj.replace);
        expect(res.uri).to.equal(expectedUri);
      }
      const { custom } = res.origin;
      if (custom.hasOwnProperty('customHeaders')) {
        expect(custom.customHeaders).to.deep.equal(originObj.customHeaders);
      }
      expect(custom.host).to.equal(originObj.host);
      expect(custom.name).to.equal(originObj.name);
      done();
    });
  });

  it(`should handle QSA correctly, both adding incoming QS and keeping the matched QS`, function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      rules: [
        {
          "type": "redirect",
          "matchPath": "^/qsa-.*",
          "location": "/omg.html?stuff=here",
          "status": 301,
          "caseSensitive": false,
          "qsa": true,
          "cacheControl": "600",

        }
      ]
    }

    const event = buildRequest("/qsa-stuff.html","works=yes");
    lambda.setConfig(stratusConfig);
		lambda.handler(event, {}, function(err, resp){
			expect(err).to.equal(null);
			expect(resp.status).to.equal(301);
			expect(resp.headers.location[0].value).to.contain("omg.html");
			expect(resp.headers.location[0].value).to.contain("works=yes");
			expect(resp.headers.location[0].value).to.contain("stuff=here");
			done();
		});
	});

  it(`should be able to reference the query string with a rule`, function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      rules: [
        {
          "type": "redirect",
          "matchPath": "^/my-voice-is-my-passport.html?verified=true",
          "location": "^/access-granted.html",
          "status": 301,
          "caseSensitive": false,
          "qsa": true,
          "cacheControl": "600",

        }
      ]
    }

    const event = buildRequest("/my-voice-is-my-passport.html","?verified=true");
    lambda.setConfig(stratusConfig);
		lambda.handler(event, {}, function(err, resp){
			expect(err).to.equal(null);
			expect(resp.status).to.equal(301);
			expect(resp.headers.location[0].value).to.contain("access-granted.html");
			done();
		});
  
  });

  it(`should not match a rule if the request doesnt match (negative of the previous)`, function(done) {
    const stratusConfig = {
      siteName: 'test.com',
      rules: [
        {
          "type": "redirect",
          "matchPath": "^/my-voice-is-my-passport.html?verified=true",
          "location": "^/access-granted.html",
          "status": 301,
          "caseSensitive": false,
          "qsa": true,
          "cacheControl": "600",

        }
      ]
    }

    const event = buildRequest("/my-voice-is-my-passport.html","?verified=false");
    lambda.setConfig(stratusConfig);
		lambda.handler(event, {}, function(err, resp){
			expect(err).to.equal(null);
			expect(resp.status).to.equal(undefined);
			expect(resp.headers.location).to.equal(undefined);
			done();
		});
	});

  it('should not have QS ending with a "&"', function (done) {
    const stratusConfig = {
      siteName: "site.com",
      rules: [
        {
          type: 'redirect',
          status: 301,
          matchPath: '^/(?.*)*$',
          location: '/d/american-express/',
          caseSensitive: false,
          qsa: true,
          cacheControl: 68400,
        }
      ]
    };

    const event = buildRequest('/', '?test=123'); // Build the request with qs

    // Set the config to one that has no headers to set
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function (err, resp) {
      expect(err).to.equal(null); // make sure there is no error
      expect(resp.status).to.equal(301);
      expect(resp.headers.location[0].value).to.equal('/d/american-express/?test=123');
      done();
    });
  });

  it('should have cache control header based on rule', function (done) {
    const stratusConfig = {
      siteName: 'site.com',
      rules: [
        {
          matchPath: '^/(?.*)*$',
          location: '/d/american-express/',
          cacheControl: 3600,
          caseSensitive: false,
          qsa: true,
          type: 'redirect',
          status: 301,
        }
      ]
    }
  
    const event = buildRequest('/', '?test=123'); // Build the request with qs
    // Set the config to one that has no headers to set
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function (err, resp) {
      expect(err).to.equal(null); // make sure there is no error
      expect(resp.status).to.equal(301);
      expect(resp.headers.location[0].value).to.equal('/d/american-express/?test=123');
      expect(resp.headers['cache-control'][0].value).to.equal(`max-age=${stratusConfig.rules[0].cacheControl}`);

      done();
    });
  });

  it('should NOT have cache control header based on rule', function (done) {
    const stratusConfig = {
      siteName: 'site.com',
      rules: [
        {
          matchPath: '^/(?.*)*$',
          location: '/d/american-express/',
          caseSensitive: false,
          qsa: true,
          type: 'redirect',
          status: 301,
        }
      ]
    }

    const event = buildRequest('/', '?test=123'); // Build the request with qs
    // Set the config to one that has no cache control headers to set
    lambda.setConfig(stratusConfig);
    lambda.handler(event, {}, function (err, resp) {
      expect(err).to.equal(null); // make sure there is no error
      expect(resp.status).to.equal(301);
      expect(resp.headers.location[0].value).to.equal('/d/american-express/?test=123');
      expect(resp.headers['cache-control']).to.equal(undefined);

      done();
    });
  });
});
