
  module.exports = function auth(req, creds, log) {
    // Get auth header value
    const headers = req.headers;

    const unauthorizedResponse = {
      status: 401,
      statusDescription: 'Unauthorized',
      headers: {
        'www-authenticate': [{
          key: 'WWW-Authenticate',
          value: 'Basic'
        }]
      }
    };

    // if there are no auth headers, stop here
    if(!req.headers.authorization){
      log.info("no Auth headers");
      return unauthorizedResponse;
    }

    // this should look like `Basic BASE64_OF_PW` 
    const authValue = req.headers.authorization[0].value.split(" ");

    if(authValue[0] !== "Basic"){
      log.info("not HTTP Basic Auth");
      return unauthorizedResponse;
    }

    // If the header is undefined they are unauthorized
    if (headers && typeof headers.authorization === 'undefined'){
      log.info("unauthorized");
      return unauthorizedResponse;
    }

    // find the user
    let foundUser = creds.find((pw) => {
      return pw === authValue[1];
    });

    // if not found, or it fond something less than 3 (not base64) they are unauthorized
    if(!foundUser || foundUser.length <= 3 ){
      log.info("user not found, or something invalid was found");
      return unauthorizedResponse; 
    }

    return req;
  };


