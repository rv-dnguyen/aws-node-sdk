'use strict';

const fs = require('fs');
const log = require('./node-lambda-log');

const originResponse = require('./lib/originResponse.js');
const requestHandler = require('./lib/request.js');
const auth = require("./auth.js");

let config;

exports.setConfig = function (obj = null) {
  if (obj) {
    global.STRATUS_CONFIG = obj;
  } else {
    global.STRATUS_CONFIG = require('./stratus-config.json');
  }
};

exports.handler = (event, context, callback) => {
  if (!global.STRATUS_CONFIG) {
    exports.setConfig();
  }

  // Redundant - I know, but doing this not to break any code in here
  config = global.STRATUS_CONFIG; // REMOVE ME LATER

  /* Get values from request */
  const request = event.Records[0].cf.request;
  const response = event.Records[0].cf.response;
  const reqId = event.Records[0].cf.config.requestId;

  // A response is set in lambda when the lambda is executing in a response event
  if (response) {
    log.config.meta.event = response;
    log.info('Handling Origin Response Trigger');
    return originResponse(response, config, callback);
  }

  log.config.meta.event = request;
  // A Lambda@Edge Viewer Request (VR) has an event property requestId which is unique to that Request
  // hook, we use that to identify if it's coming from a Viewer Request. A VR also does not contain an origin property
  // so we pair those two things up and check whether a Request has a requestId and does not contain the origin property
  // AWS Docs on Lambda@Edge Event: https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/lambda-event-structure.html#lambda-event-structure-request
  if (reqId && !request.origin) {
    log.info(`Handling Viewer Request Trigger (RequestId: ${reqId}), Auth Required`);
    let creds;
    try {
      creds = JSON.parse(fs.readFileSync("./.allowedUsers.json").toString());
    } catch (e) {
      log.error(e);
      // Let's make sure that we do not serve the site
      creds = [];
    }

    const authResponse = auth(request, creds, log);
    // If it came back with a 401, return that response
    // otherwise, let the request go, its correctly authenticated
    if (authResponse.status === 401) {
      log.info(`Ending Viewer Request Trigger (RequestId: ${reqId}), Auth was unsuccessful`);
      return callback(null, authResponse);
    }
    
    // If we are authenticated then just return the request and let it flow towards the origin
    // This will keep the routing logic on the Origin Request Trigger, having the VR only take care 
    // of making sure the viewer in authenticated.
    log.info(`Handling Viewer Request Trigger (RequestId: ${reqId}), Auth was successful`);
    return callback(null, request);
  }

  log.info('Handling Origin Request Trigger');
  return requestHandler(request, config, callback);
};